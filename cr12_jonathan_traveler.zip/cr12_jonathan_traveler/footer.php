	<div>

</div>

<footer>
    <p>&copy; <?php echo Date('Y'); ?> <?php bloginfo('name'); ?></p>
    <p>
    <a href="#">Back to top</a>
    </p>

</footer>

<!--wp_footer() loads javascript files used by plugins, as well as adds the Wordpress black navigation bar to the top of the page. -->

<?php wp_footer(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

</body>
</html>


</div>